# kjh-vita

A simple `.tex` template for making a nicely-formatted academic curriculum vitae. I use this as a template for [my own vita](http://kieranhealy.org/vita.pdf) and put it up here because people regularly emailed me asking for the `.tex` source.
